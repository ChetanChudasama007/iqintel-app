module.exports = {
    "trailingComma": "es5",
    "useTabs": true,
    "semi": true,
    "singleQuote": false,
    "newline-before-return": "true"
};
  